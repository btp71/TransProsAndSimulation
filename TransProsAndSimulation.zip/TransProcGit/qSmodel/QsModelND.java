package qSmodel;

import java.util.HashMap;
import java.util.Map;

import process.Dispatcher;
import view.TransGUI;

//Model for exploring device number influence
public class QsModelND extends QsModel {

	public QsModelND(Dispatcher d, TransGUI g) {
		super(d, g);
	}


	//Implementation ITransExprable interface 

	@Override
	//Model initialization method
	public void initForTrans(double factor, double finishTime) {
		getMultiDevice().setNumberOfClones((int) factor);
		double mDev = getDevice().getRndDev().average();
		getDevice().getRndDev().average(factor * mDev);
		getGenerator().setFinishTime(finishTime);
		getDevice().setFinishTime(finishTime);

	}

	@Override
	//Access to queue method
	public Map<String, ITransMonitorable> getMonitoringObjects() {
		Map<String, ITransMonitorable> map = new HashMap<>();
		map.put("TransactionQueue ", 
				(ITransMonitorable)getQueue());
		return map;
	}
}
