package qSmodel;

import java.util.HashMap;
import java.util.Map;

import process.Dispatcher;
import view.TransGUI;

//Model for exploring load factor influence
public class QsModelLF extends QsModel {
	
	//Implementation ITransExprable interface 

	public QsModelLF(Dispatcher d, TransGUI g) {
		super(d, g);
	}

	@Override
	//Model initialization method
	public void initForTrans(double factor, double finishTime) {	
		double mGen = getGenerator().getRndGen().average();
		int n = getMultiDevice().getNumberOfClones();
		getDevice().getRndDev().average(factor * mGen*n);
		getGenerator().setFinishTime(finishTime);
		getDevice().setFinishTime(finishTime);
	}

	@Override
	//Access to queue method
	public Map<String, ITransMonitorable> getMonitoringObjects() {
		Map<String, ITransMonitorable> map = new HashMap<>();
		map.put("TransactionQueue ", 
				(ITransMonitorable)getQueue());
		return map;
	}
}
