package regresProc;

import finder.FinderByGradient;

public class RgrsProcExpGr extends FinderByGradient {
	

	public RgrsProcExpGr() {
		setStep(0.001);
		setStartArray(new double[] {1.0,1.0});
	}

	@Override
	public double funcRegres(double t, double[] parmAr) {
	    double k = parmAr[0];
	    double tau = parmAr[1];
		return k*(1- Math.exp(-t/tau));
	}

	@Override
	public String toString() {
		return "(gr)level*(1- e^(-t/tau))";
	}

	
	
}
