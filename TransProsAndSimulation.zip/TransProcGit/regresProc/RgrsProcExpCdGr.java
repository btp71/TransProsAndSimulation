package regresProc;

import finder.FinderByCdGr;

public class RgrsProcExpCdGr extends FinderByCdGr {

	@Override
	public double funcRegres(double t, double[] parmAr) {
    double k = parmAr[0];
    double tau = parmAr[1];
	return k*(1- Math.exp(-t/tau));
}	
	
	@Override
	protected double[] getCdGrStartArray() {
		return new double[] {1.0, 1.0};
	}

	@Override
	protected double[] getCdStepArray() {
		return new double[] {0.001, 0.001};
	}

	@Override
	protected double getGrStep() {
		return 0.001;
	}	

	public String toString() {
		return "(cdgr)levl*(1-e^(-x/tau))";
	}
}
