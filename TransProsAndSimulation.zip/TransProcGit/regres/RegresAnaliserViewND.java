package regres;

import javax.swing.DefaultComboBoxModel;

import finder.IFinderRegresParm;
import regresDpnd.Regres1CdGrPow7;
import regresDpnd.Regres1Tg;
import regresDpnd.Regres1Undepend;
import regresDpnd.Regres1_0Qavg;
import regresDpnd.Regres1_2;
import regresDpnd.Regres1_3;
import regresDpnd.Regres2Giperbola;
import regresDpnd.Regres2Linear;
import regresDpnd.Regres2exp;
import regresDpnd.Regres3CdGr;
import regresDpnd.Regres3CdGrPow;
import regresDpnd.Regres3exppow;

public class RegresAnaliserViewND extends RegresAnaliserView {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Override
	protected DefaultComboBoxModel<IFinderRegresParm>
	getDefaultComboBoxModel() {

	if (defaultComboBoxModel == null) {
		defaultComboBoxModel = new DefaultComboBoxModel<>();		
		defaultComboBoxModel.addElement(new Regres1Undepend());
		defaultComboBoxModel.addElement(new Regres2Linear());
		defaultComboBoxModel.addElement(new Regres2Giperbola()); 
		defaultComboBoxModel.addElement(new Regres1_0Qavg());
		defaultComboBoxModel.addElement(new Regres1CdGrPow7());
		defaultComboBoxModel.addElement(new Regres3CdGrPow());
		defaultComboBoxModel.addElement(new Regres3CdGr());
		defaultComboBoxModel.addElement(new Regres1_2());
		defaultComboBoxModel.addElement(new Regres1_3());
		defaultComboBoxModel.addElement(new Regres1Tg());
		defaultComboBoxModel.addElement(new Regres2exp());
		defaultComboBoxModel.addElement(new Regres3exppow());
	}
	return defaultComboBoxModel;
}

}
