package trans;

import process.IModelFactory;
import qSmodel.QsModelND;
import regres.RegresAnaliserView;
import regres.RegresAnaliserViewND;

public class TransExprManagerND extends TransExprManager{

	@Override
	protected String getFactorListText() {
	
		return "3 5 7 9 11";
	}

	@Override
	protected String getFactorListTitle() {
		
		return "Device number as factor";
	}

	@Override
	protected double getFactorValueForTest() {
	
		return parmSource.getNdevice();
	}
	
	@Override
	protected IModelFactory getModelFactory() {
		return (d)-> new QsModelND(d,parmSource);
	}
	@Override
	protected RegresAnaliserView getRegresAnaliser() {
		if(regresAnaliser == null) {
			regresAnaliser = new RegresAnaliserViewND();
		}
		return regresAnaliser;
	}
}
