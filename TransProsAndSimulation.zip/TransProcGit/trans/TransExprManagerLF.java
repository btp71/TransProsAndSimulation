package trans;

import process.IModelFactory;
import qSmodel.QsModelLF;
import regres.RegresAnaliserView;
import regres.RegresAnaliserViewLF;

public class TransExprManagerLF extends TransExprManager{

	@Override
	protected String getFactorListText() {
		return "0.6 0.7 0.8 0.85 0.9";
	}

	@Override
	protected String getFactorListTitle() {

		return "Load factor";
	}

	@Override
	protected double getFactorValueForTest() {
		double b =  parmSource.getChooseRandomGen().average();
		double d =  parmSource.getChooseRandomDev().average();
		return d/b;
	}
	
	@Override
	protected IModelFactory getModelFactory() {
		return (d)-> new QsModelLF(d,parmSource);
	}

	@Override
	protected RegresAnaliserView getRegresAnaliser() {
		if(regresAnaliser == null) {
			regresAnaliser = new RegresAnaliserViewLF();
		}
		return regresAnaliser;
	}
}
