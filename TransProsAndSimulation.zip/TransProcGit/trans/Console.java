package trans;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class Console extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	private JPanel panel;
	private JLabel lblFontSize;
	private JSpinner spinner;


	/**
	 * Create the frame.
	 */
	public Console() {
		setTitle("Model activity protocol");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(1, 0, 0, 0));
		contentPane.add(getScrollPane());
	}

	public JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getTextArea());
			scrollPane.setColumnHeaderView(getPanel());
		}
		return scrollPane;
	}
	public JTextArea getTextArea() {
		if (textArea == null) {
			textArea = new JTextArea();
			textArea.setWrapStyleWord(true);
			textArea.setMargin(new Insets(2, 5, 2, 2));
			textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
		}
		return textArea;
	}

	public JLabel getLblFontSize() {
		if (lblFontSize == null) {
			lblFontSize = new JLabel("Font size");
		}
		return lblFontSize;
	}
	public JSpinner getSpinner() {
		if (spinner == null) {
			spinner = new JSpinner();
			spinner.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					stateChangedSpinner(e);
				}
			});

			spinner.setModel(new SpinnerNumberModel(12, 10, 24, 2));
		}
		return spinner;
	}
	protected void stateChangedSpinner(ChangeEvent e) {
		int size = (int) spinner.getValue();
		Font font =new Font(Font.MONOSPACED, Font.PLAIN, size);
		textArea.setFont(font );
		textArea.setText(textArea.getText());
	}
	public JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.add(getLblFontSize());
			panel.add(getSpinner());
		}
		return panel;
	}
	public Console print(String str) {
		EventQueue.invokeLater(
				new Runnable() {
					public void run() {
						getTextArea().append(str);
						int pos= getTextArea().getDocument().getLength();
						getTextArea().select(pos-1, pos);
					}
				});
	
		return this;
	}


}

