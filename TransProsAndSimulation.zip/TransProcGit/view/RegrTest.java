package view;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;

import widgets.ChooseData;
import widgets.Diagram;
import widgets.regres.IRegresable;
import widgets.regres.RegresAnaliser;

public class RegrTest implements IRegresable {

	private JFrame frame;
	private ChooseData chooseData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegrTest window = new RegrTest();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegrTest() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 348);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 24, 0};
		gridBagLayout.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);

		Diagram diagram = new Diagram();
		diagram.setTitleText("\u041A\u043E\u0435\u0444\u0456\u0446\u0456\u0435\u043D\u0442 \u0444-\u0456\u0457 \u0440\u0435\u0433\u0440\u0435\u0441\u0456\u0457");
		GridBagConstraints gbc_diagram = new GridBagConstraints();
		gbc_diagram.insets = new Insets(0, 0, 5, 5);
		gbc_diagram.fill = GridBagConstraints.BOTH;
		gbc_diagram.gridx = 0;
		gbc_diagram.gridy = 1;
		frame.getContentPane().add(diagram, gbc_diagram);

		RegresAnaliser regresAnaliser = new RegresAnaliser();
		regresAnaliser.setIRegresable(this);
		regresAnaliser.setDiagram(diagram);
		GridBagConstraints gbc_regresAnaliser = new GridBagConstraints();
		gbc_regresAnaliser.insets = new Insets(0, 0, 5, 0);
		gbc_regresAnaliser.fill = GridBagConstraints.BOTH;
		gbc_regresAnaliser.gridx = 1;
		gbc_regresAnaliser.gridy = 1;
		frame.getContentPane().add(regresAnaliser, gbc_regresAnaliser);

		chooseData = new ChooseData();
		chooseData.setTitle("\u0414\u0430\u043D\u0456");
		chooseData.setText("42.87 43.87 44.05 44.16 44.41  42.96  44.20 42.93 43.51 44.33  43.29 43.45 43.54 44.9 42.66");
		GridBagConstraints gbc_chooseData = new GridBagConstraints();
		gbc_chooseData.insets = new Insets(0, 0, 5, 0);
		gbc_chooseData.gridwidth = 2;
		gbc_chooseData.fill = GridBagConstraints.HORIZONTAL;
		gbc_chooseData.gridx = 0;
		gbc_chooseData.gridy = 2;
		frame.getContentPane().add(chooseData, gbc_chooseData);
		
		ChooseData chooseData_1 = new ChooseData();
		chooseData_1.setMinimumSize(new Dimension(50, 25));
		chooseData_1.setPreferredSize(new Dimension(56, 30));
		chooseData_1.setTitle("");
		GridBagConstraints gbc_chooseData_1 = new GridBagConstraints();
		gbc_chooseData_1.gridwidth = 2;
		gbc_chooseData_1.insets = new Insets(0, 0, 0, 5);
		gbc_chooseData_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_chooseData_1.gridx = 0;
		gbc_chooseData_1.gridy = 3;
		frame.getContentPane().add(chooseData_1, gbc_chooseData_1);
	}

	public ChooseData getChooseData() {
		return chooseData;
	}

	@Override
	public Map<Double, List<Double>> getResultMap() {

		double ar[] =chooseData.getDoubleArray();
		List<Double> list = new ArrayList<>();
		for (double y : ar) {
			list.add(y);
		}
		Map<Double, List<Double>> map = new HashMap<>();		
		map.put(1.0, list);
		return map;
	}
}
