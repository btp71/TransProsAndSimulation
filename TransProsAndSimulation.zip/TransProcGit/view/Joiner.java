package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentSkipListMap;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import regres.RegresAnaliserView;
import regres.RegresAnaliserViewLF;
import widgets.ChooseData;
import widgets.Diagram;

public class Joiner {

	private JFrame frame;
	private JComboBox<String> comboBox;

	//����� � ������������ ��� ������������
	private Map<String, Map<Double,Queue<Double>>> workResultsMap;
	private Map<String, Map<Double,Queue<Double>>> joinedResultsMap;
	private Diagram diagram;
	private RegresAnaliserViewLF regresAnaliserView;
	private JLabel lblFileName;
	private JLabel lblParameters;
	private ChooseData chooseDataFactors;
	private String[] parmNameArr;



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(
							UIManager.getSystemLookAndFeelClassName());
					Joiner window = new Joiner();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Joiner() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 762, 515);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{299, 239, 0};
		gridBagLayout.rowHeights = new int[]{29, 29, 258, 23, 0};
		gridBagLayout.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);

		lblParameters = new JLabel("Fghzhsjsjds\\");
		lblParameters.setHorizontalAlignment(SwingConstants.CENTER);
		lblParameters.setBorder(new TitledBorder(null, "Parameters", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		GridBagConstraints gbc_lblParameters = new GridBagConstraints();
		gbc_lblParameters.fill = GridBagConstraints.BOTH;
		gbc_lblParameters.insets = new Insets(0, 0, 5, 0);
		gbc_lblParameters.gridwidth = 2;
		gbc_lblParameters.gridx = 0;
		gbc_lblParameters.gridy = 0;
		frame.getContentPane().add(lblParameters, gbc_lblParameters);

		lblFileName = new JLabel("hdjhdjdj");
		lblFileName.setBorder(new TitledBorder(null, "File", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		GridBagConstraints gbc_lblFileName = new GridBagConstraints();
		gbc_lblFileName.anchor = GridBagConstraints.EAST;
		gbc_lblFileName.insets = new Insets(0, 0, 5, 5);
		gbc_lblFileName.gridx = 0;
		gbc_lblFileName.gridy = 1;
		frame.getContentPane().add(lblFileName, gbc_lblFileName);

		chooseDataFactors = new ChooseData();
		chooseDataFactors.setTitle("Load factor array");
		GridBagConstraints gbc_chooseDataFactors = new GridBagConstraints();
		gbc_chooseDataFactors.insets = new Insets(0, 0, 5, 0);
		gbc_chooseDataFactors.fill = GridBagConstraints.HORIZONTAL;
		gbc_chooseDataFactors.gridx = 1;
		gbc_chooseDataFactors.gridy = 1;
		frame.getContentPane().add(chooseDataFactors, gbc_chooseDataFactors);

		diagram = new Diagram();
		GridBagConstraints gbc_diagram = new GridBagConstraints();
		gbc_diagram.insets = new Insets(0, 0, 5, 5);
		gbc_diagram.fill = GridBagConstraints.BOTH;
		gbc_diagram.gridx = 0;
		gbc_diagram.gridy = 2;
		frame.getContentPane().add(diagram, gbc_diagram);

		regresAnaliserView = new RegresAnaliserViewLF();
		GridBagConstraints gbc_regresAnaliserView = new GridBagConstraints();
		gbc_regresAnaliserView.insets = new Insets(0, 0, 5, 0);
		gbc_regresAnaliserView.fill = GridBagConstraints.BOTH;
		gbc_regresAnaliserView.gridx = 1;
		gbc_regresAnaliserView.gridy = 2;
		frame.getContentPane().add(regresAnaliserView, gbc_regresAnaliserView);

		comboBox = new JComboBox();
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.anchor = GridBagConstraints.NORTH;
		gbc_comboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBox.insets = new Insets(5, 5, 0, 5);
		gbc_comboBox.gridx = 0;
		gbc_comboBox.gridy = 3;
		frame.getContentPane().add(comboBox, gbc_comboBox);

		JButton btnRedraw = new JButton("Redraw");
		btnRedraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(workResultsMap != null)
					redraw(workResultsMap);
				else if(joinedResultsMap != null)
					redraw(joinedResultsMap );
			}
		});
		GridBagConstraints gbc_btnRedraw = new GridBagConstraints();
		gbc_btnRedraw.insets = new Insets(5, 5, 0, 0);
		gbc_btnRedraw.anchor = GridBagConstraints.NORTH;
		gbc_btnRedraw.gridx = 1;
		gbc_btnRedraw.gridy = 3;
		frame.getContentPane().add(btnRedraw, gbc_btnRedraw);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenuItem mntmAdd = new JMenuItem("Add");
		mntmAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onAdd();
			}
		});
		mnFile.add(mntmAdd);

		JMenuItem mntmStore = new JMenuItem("Store");
		mnFile.add(mntmStore);

		JMenuItem mntmBase = new JMenuItem("CreateBase ");
		mntmBase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onCreateBase();
			}
		});
		mnFile.add(mntmBase);

		JMenuItem mntmResetBase = new JMenuItem("ResetBase");
		mnFile.add(mntmResetBase);

		JMenuItem mntmLoadFile = new JMenuItem("Load File");
		mntmLoadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onLoadFile();
			}
		});
		menuBar.add(mntmLoadFile);

		JMenuItem mntmAddToAll = new JMenuItem("AddToAll");
		mntmAddToAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onAddToAll();
			}
		});
		menuBar.add(mntmAddToAll);

		JMenuItem mntmStoreAll = new JMenuItem("StoreAll");
		mntmStoreAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onStore();
			}
		});
		menuBar.add(mntmStoreAll);
	}
	protected void onAddToAll() {
		if(workResultsMap == null) {
			JOptionPane.showMessageDialog(frame, 
					"Work file was not load!");
			return;
		}
		// workResultsMap already exists
		double[] factors = chooseDataFactors.getDoubleArray();
		if(joinedResultsMap == null) {
			// ��������� ����� ��� ����������
			//Map classes the same as in TransExprManagerLF
			joinedResultsMap = new ConcurrentSkipListMap<>();
			for (String key : parmNameArr) {
				ConcurrentMap<Double, Queue<Double>> 
				newSubMap = new ConcurrentHashMap<>();		
				ConcurrentMap<Double, Queue<Double>> 
				workSubMap = (ConcurrentMap<Double, Queue<Double>>) workResultsMap.get(key);
				for (double f : factors) {
					newSubMap.put(f, 
							workSubMap.get(f));
					joinedResultsMap.put(key, newSubMap);
				}
			}
		}	
		else {
			for (String key : parmNameArr) {
				ConcurrentMap<Double, Queue<Double>> 
				subMap = (ConcurrentMap<Double, Queue<Double>>) 
				joinedResultsMap.get(key);		
				ConcurrentMap<Double, Queue<Double>> 
				workSubMap = (ConcurrentMap<Double, Queue<Double>>) 
				workResultsMap.get(key);
				for (double f : factors) {
					subMap.put(f, 
							workSubMap.get(f));
					joinedResultsMap.put(key, subMap);
				}
			}

		}

		workResultsMap = null;
		regresAnaliserView.setDataMap(getDataMap(joinedResultsMap));
		redraw(joinedResultsMap);

	}

	protected void onLoadFile() {

		//File selection
		JFileChooser fileChooser = new JFileChooser(
				"������������ ���������� ������������");
		fileChooser.showOpenDialog(null);
		File f = fileChooser.getSelectedFile();
		String fName = f.getAbsolutePath();
		lblFileName.setText(fName);

		//Selected file deserialisation
		//8	Map<String, Map<Double, Queue<Double>>> resultsMap;
		try {
			// ��������� ���� ��� ������������ ����� ������
			ObjectInputStream in = new ObjectInputStream(
					new FileInputStream(fName));
			workResultsMap = (Map<String, Map<Double, Queue<Double>>>)
					in.readObject(); // ������������
			in.close(); // �������� ����

		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null, 
					"������� ������������ ",
					"������������", JOptionPane.ERROR_MESSAGE);
			return;
		}
		//Map parameters exploring
		Set<String> parmNameSet = workResultsMap.keySet();
		parmNameArr = parmNameSet.toArray(new String[0]);
		lblParameters.setText(Arrays.toString(parmNameArr));


		comboBox.setModel(new DefaultComboBoxModel<String>
		(parmNameArr));
		comboBox.setSelectedIndex(0);
		regresAnaliserView.setDataMap(getDataMap(workResultsMap));
		redraw(workResultsMap);



		Map<Double, Queue<Double>> firstResultMap =
				workResultsMap.	get(parmNameArr[0]);
		Set<Double>
		factorSet = 
		(Set<Double>)firstResultMap.keySet();

		Double[] factorArr = factorSet.toArray(new Double[0]);
		String str = Arrays.toString(factorArr);
		str = str.replaceAll("[\\[\\],]", " ");


		chooseDataFactors.setText(str);
		//	redraw(diagram);
		//regresAnaliserView.setDataMap(resultsMap);
	}

	protected void onAdd() {
		if(workResultsMap == null) {
			onCreateBase();
			JOptionPane.showMessageDialog(frame, "Base map created!");
			return;
		}
		Map<String, Map<Double, Queue<Double>>> addMap = readMap();	
		Set<String> strBaseSet = workResultsMap.keySet();
		for (String key : strBaseSet) {
			Map<Double, Queue<Double>> dblBaseMap = 
					workResultsMap.get(key);
			Map<Double, Queue<Double>> dblAddMap = addMap.get(key);
			for (Map.Entry<Double, Queue<Double>> entry : dblAddMap.entrySet()) {
				Double dblAdd = entry.getKey();
				Queue<Double> queAdd = entry.getValue();

				Queue<Double> baseQue = dblBaseMap.get(dblAdd);
				if(baseQue == null)
					dblBaseMap.put(dblAdd, queAdd);
				else {
					baseQue.addAll(queAdd);
					dblBaseMap.put(dblAdd, baseQue);
				}
			}
		}
		regresAnaliserView.setDataMap(getDataMap(joinedResultsMap));
		redraw(joinedResultsMap);
	}

	protected void onCreateBase() {
		if(workResultsMap != null) {
			JOptionPane.showMessageDialog(frame, "Map already exist!");
			return;
		}
		workResultsMap = readMap();
		Set<String> keys = workResultsMap.keySet();
		String[] keyStrings = (String[]) keys.
				toArray(new String[0]);
		comboBox.setModel(new DefaultComboBoxModel<String>
		(keyStrings));
		comboBox.setSelectedIndex(0);
		//		regresAnaliserView.setDataMap(getDataMap());
		//		redraw();
	}

	protected Map<String, Map<Double, Queue<Double>>> readMap() {
		JFileChooser fileChooser = new JFileChooser(
				"������������ ���������� ������������");
		fileChooser.showOpenDialog(null);
		File f = fileChooser.getSelectedFile();
		String fName = f.getAbsolutePath();
		Map<String, Map<Double, Queue<Double>>> resultsMap;		
		try {
			// ��������� ���� ��� ������������ ����� ������
			ObjectInputStream in = new ObjectInputStream(
					new FileInputStream(fName));
			resultsMap = (Map<String, Map<Double, Queue<Double>>>)
					in.readObject(); // ������������
			in.close(); // �������� ����
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null, 
					"������� ������������ ",
					"������������", JOptionPane.ERROR_MESSAGE);
			return null;
		}

		return resultsMap;
	}

	//����� ���������� ���������� ������������ � ����
	protected void onStore() {
		if(joinedResultsMap == null) return;
		JFileChooser fileChooser = new JFileChooser(
				"Results serialisation");
		fileChooser.showSaveDialog(null);
		try {
			File f = fileChooser.getSelectedFile();
			String fName = f.getAbsolutePath();
			FileOutputStream fileStream = 
					new FileOutputStream(fName);
			ObjectOutputStream out = 
					new ObjectOutputStream(fileStream);
			out.writeObject(joinedResultsMap);//���������� ��'���
			out.close(); // ��������� ����
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null, 
					"������� �������� �����", 
					"���������� ������ � ����",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
	}

	//����� ���������� ���������� �� ������
	public void redraw(Map<String, Map<Double, Queue<Double>>> map2) {
		onFactorChange();
		// Search for max vertical value
		double max = Double.MIN_VALUE;
		for (Double factor : getDataMap(map2).keySet()) {
			List<Double> resultList = getDataMap(map2).get(factor);
			for (Double result : resultList) {
				if(result > max)
					max = result;
			}
		}	
		if(max == Double.MIN_VALUE)
			return;
		double k = 1;
		while(max*k < 1) k *= 10;
		while(max*k >= 10) k/=10;	
		double n = k*max;		
		double[][] bounds = {
				{1.5, 2, 4, 5, 7.5, 8, 10},
				{5, 4, 4, 5,  5,  4, 5} };
		int i = 0;
		while(n > bounds[0][i]) i++;
		max = bounds[0][i] / k;
		String maxY;
		if(max <10)
			maxY = String.format(Locale.ROOT,"%1.2f", max);
		else
			maxY = String.format(Locale.ROOT,"%d", (int)max);		
		diagram.setVerticalMaxText(maxY);
		diagram.setGridByY((int)bounds[1][i]);
		diagram.getPainter().setColor(new Color(0, 0, 255));
		diagram.clear();		
		for (Double factor : getDataMap(map2).keySet()) {
			List<Double> resultList = getDataMap(map2).get(factor);
			for (Double result : resultList) {
				diagram.getPainter().drawOvalAtXY(factor.floatValue(),
						result.floatValue(), 8,8);
			}
		}
	}

	public Map<Double, List<Double>> getDataMap(Map<String, 
			Map<Double, Queue<Double>>> mapForShow) {
		//���������� ������ ������������ �� ��������� �������
		Map<Double, List<Double>> returnMap = new TreeMap<>();
		String key = (String) comboBox.getSelectedItem();
		if (key != null && mapForShow != null) {
			Map<Double, Queue<Double>> map =
					mapForShow.get(key);
			Set<Double> setFact = map.keySet();
			//Pull out factors array
			int i = 0;
			double[] factors = new double[setFact.size()];
			for (Double d : setFact) {
				factors[i++] = d;
			}
			Arrays.sort(factors);

			Map<Double, Queue<Double>> subMap = mapForShow.get(key);
			for (double f : factors) {
				ArrayList<Double> arr = new ArrayList<>();
				for (Double y : subMap.get(f)) {
					arr.add(y);
				}
				returnMap.put(f, arr);
			}
		}
		return returnMap;

	}
	private void onFactorChange() {
		try {
			double[] ar = getFactors();
			String minX, maxX;
			Arrays.sort(ar);
			double[] minMaxGrid = calcMinMax(ar);
			if(ar.length > 1) {
				//calc minX
				if(minMaxGrid[0] < 1)
					minX = String.format(Locale.ROOT,"%1.2f", minMaxGrid[0]);
				else
					minX = String.format(Locale.ROOT,"%1.1f",minMaxGrid[0]);		
				//calc maxX
				if(minMaxGrid[1] < 1)
					maxX = String.format(Locale.ROOT,"%1.2f", minMaxGrid[1]);
				else
					maxX = String.format(Locale.ROOT,"%1.1f",minMaxGrid[1]);
			}else {
				double min = ar[0]==0 ? -0.5 : 0.5*ar[0];
				minX = String.format(Locale.ROOT,"%1.2f", min);
				double max = ar[0]==0 ? 0.5 : 1.5*ar[0];
				maxX = String.format(Locale.ROOT,"%1.2f", max);
			}
			diagram.setHorizontalMinText(minX);
			diagram.setHorizontalMaxText(maxX);
			diagram.setGridByX((int)minMaxGrid[2]);

		} catch (Exception e2) {}

	}
	double[] getFactors() {
		double[] factors = null;
		String key = (String) comboBox.getSelectedItem();
		if (key != null) {
			Map<Double, Queue<Double>> map =
					workResultsMap.get(key);
			Set<Double> setFact = map.keySet();
			//Pull out factors array
			int i = 0;
			factors = new double[setFact.size()];
			for (Double d : setFact) {
				factors[i++] = d;
			}
			Arrays.sort(factors);
		}
		return factors;
	}
	private double[] calcMinMax(double[] ar) {
		double minH = ar[0];
		double maxH = ar[ar.length - 1];
		double dH = 9999999; 
		Double pred = null;
		for(Double d :ar) {
			if( pred !=null && !d.equals(pred) && d - pred < dH) 
				dH = d - pred;
			pred = d;
		}
		minH -= dH;
		maxH += dH;
		int gridX = (int)((maxH - minH) / dH + 0.5);
		maxH = minH + dH*gridX;
		double[] res = {minH, maxH, gridX};
		return res;
	}


	public Diagram getDiagram() {
		return diagram;
	}

	public RegresAnaliserView getRegresAnaliserView() {
		return regresAnaliserView;
	}
	public JLabel getLblFileName() {
		return lblFileName;
	}
	public JLabel getLblParameters() {
		return lblParameters;
	}

	public ChooseData getChooseDataFactors() {
		return chooseDataFactors;
	}
}

