package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import rnd.Erlang;
import rnd.Negexp;
import trans.TransExprManagerLF;
import trans.TransExprManagerND;
import widgets.ChooseData;
import widgets.ChooseRandom;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class TransGUI extends JFrame{

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JPanel jPanelModelParameters = null;

	private ChooseRandom chooseRandomGen = null;

	private ChooseRandom chooseRandomDev = null;

	private ChooseData chooseDataQmaxSize = null;

	private ChooseData chooseDataFinishTime = null;
	private JTabbedPane tabbedPane;
	JFrame frameParmFinder;
	private ChooseData chooseDataDeviceNumber;
	private ChooseData chooseDataAccumTime;
	private ChooseData chooseDataNmodel;
	
	private TransExprManagerLF transExprManagerLF;
	private TransExprManagerND transExprManagerND;

	public TransGUI() {
		super();
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				try {
					frameParmFinder.setVisible(false);
					frameParmFinder.dispose();
				} catch (Exception e1) {

				}
			}
		});
		initialize();
	}

	/**
	 * This method initializes jPanelModelParameters
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelModelParameters() {
		if (jPanelModelParameters == null) {
			jPanelModelParameters = new JPanel();
			jPanelModelParameters
			.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), "Queued system parameters", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(51, 51, 51)));
			jPanelModelParameters.setPreferredSize(new Dimension(262, 436));
			jPanelModelParameters.setMinimumSize(new Dimension(262, 436));
			jPanelModelParameters.setLayout(new GridLayout(7, 1, 0, 0));
			jPanelModelParameters.add(getChooseRandomGen());
			jPanelModelParameters.add(getChooseRandomDev());
			jPanelModelParameters.add(getChooseDataQmaxSize());
			jPanelModelParameters.add(getChooseDataDeviceNumber());
			jPanelModelParameters.add(getChooseDataAccumTime());
			jPanelModelParameters.add(getChooseDataFinishTime());
			jPanelModelParameters.add(getChooseDataNmodel());
		}
		return jPanelModelParameters; 
	}

	/**
	 * This method initializes rndBuldo	
	 * 	
	 * @return widgets.ChooseRandom	
	 */
	public ChooseRandom getChooseRandomGen() {
		if (chooseRandomGen == null) {
			chooseRandomGen = new ChooseRandom();
			chooseRandomGen.setRandom(new Negexp(1));
			chooseRandomGen.setTitle("Arrived interval");
		}
		return chooseRandomGen;
	}


	/**
	 * This method initializes rndLoader	
	 * 	
	 * @return widgets.ChooseRandom	
	 */
	public ChooseRandom getChooseRandomDev() {
		if (chooseRandomDev == null) {
			chooseRandomDev = new ChooseRandom();
			chooseRandomDev.setRandom(new Erlang(0.75,2));
			chooseRandomDev.setTitle("Service time");
		}
		return chooseRandomDev;
	}

	/**
	 * This method initializes chooseDataHeapMaxSize	
	 * 	
	 * @return widgets.ChooseData	
	 */
	public ChooseData getChooseDataQmaxSize() {
		if (chooseDataQmaxSize == null) {
			chooseDataQmaxSize = new ChooseData();
			chooseDataQmaxSize.setTitle("Queue max size");
			chooseDataQmaxSize.setInt(Integer.MAX_VALUE);

		}
		return chooseDataQmaxSize;
	}


	/**
	 * This method initializes chooseDataFinishTime	
	 * 	
	 * @return widgets.ChooseData	
	 */
	public ChooseData getChooseDataFinishTime() {
		if (chooseDataFinishTime == null) {
			chooseDataFinishTime = new ChooseData();
			chooseDataFinishTime.addCaretListener(new CaretListener() {
				public void caretUpdate(CaretEvent e) {
					onChangeFinishTime();
				}
			});
			chooseDataFinishTime.setTitle("Modeling time");
			chooseDataFinishTime.setText("250");
	
		}
		return chooseDataFinishTime;
	}


	protected void onChangeFinishTime() {
		try {
			if(getChooseDataFinishTime().getDouble() == 0) return;
			double accumTime = getChooseDataAccumTime().getDouble();
			if(accumTime == 0) return;
			int n = (int) (getChooseDataFinishTime().getDouble()/accumTime);

			double realFinishTime = n*accumTime;
			if(getChooseDataFinishTime().getDouble() != realFinishTime)
			     getChooseDataFinishTime().setDouble(realFinishTime);
		} catch (Exception e) {
		
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TransGUI application = new TransGUI();
		application.setVisible(true);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel(
					UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException
				| UnsupportedLookAndFeelException e) {
		
			e.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(949, 489);
		this.setContentPane(getJContentPane());
		this
		.setTitle("Exploring the Transient Behavior "
				+ "in Queueing Systems by Simulation");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
			gridBagConstraints7.ipadx = -50;
			gridBagConstraints7.anchor = GridBagConstraints.WEST;
			gridBagConstraints7.insets = new Insets(9, 10, 7, 5);
			gridBagConstraints7.gridy = 0;
			gridBagConstraints7.gridx = 0;
			jContentPane = new JPanel();
			GridBagLayout gbl_jContentPane = new GridBagLayout();
			gbl_jContentPane.rowWeights = new double[]{1.0};
			gbl_jContentPane.columnWeights = new double[]{0.0, 1.0};
			gbl_jContentPane.columnWidths = new int[]{204, 0};
			jContentPane.setLayout(gbl_jContentPane);
			jContentPane.add(getJPanelModelParameters(), gridBagConstraints7);
			GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
			gbc_tabbedPane.fill = GridBagConstraints.BOTH;
			gbc_tabbedPane.gridx = 1;
			gbc_tabbedPane.gridy = 0;
			jContentPane.add(getTabbedPane(), gbc_tabbedPane);
		}
		return jContentPane;
	}

	public ChooseData getChooseDataDeviceNumber() {
		if (chooseDataDeviceNumber == null) {
			chooseDataDeviceNumber = new ChooseData();
			chooseDataDeviceNumber.setTitle("Number of devices");
			chooseDataDeviceNumber.setText("5");
		}
		return chooseDataDeviceNumber;
	}
	private ChooseData getChooseDataAccumTime() {
		if (chooseDataAccumTime == null) {
			chooseDataAccumTime = new ChooseData();
			chooseDataAccumTime.addCaretListener(new CaretListener() {
				public void caretUpdate(CaretEvent e) {
					onChangeAccumTime();
				}
			});
			chooseDataAccumTime.setTitle("Accum interval");
			chooseDataAccumTime.setText("5");
		}
		return chooseDataAccumTime;
	}
	protected void onChangeAccumTime() {
		try {
			double accumTime = getChooseDataAccumTime().getDouble();
			if(accumTime == 0) return;

			int n = (int) (getChooseDataFinishTime().getDouble()/accumTime);
			double newFinishTime = n*accumTime;
			if(getChooseDataFinishTime().getDouble() != newFinishTime)
			     getChooseDataFinishTime().setDouble(newFinishTime);
		} catch (Exception e) {
			
		}
	
	}

	private ChooseData getChooseDataNmodel() {
		if (chooseDataNmodel == null) {
			chooseDataNmodel = new ChooseData();
			chooseDataNmodel.setTitle("Number of models");
			chooseDataNmodel.setText("500");
		}
		return chooseDataNmodel;
	}

	private JTabbedPane getTabbedPane() {
		if (tabbedPane == null) {
			tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane.addTab("Load Factor influence", null, getTransExprtManagerLF(), null);
			tabbedPane.addTab("Device Number influence", null, getTransExprManagerND(), null);
		}
		return tabbedPane;
	}
	private TransExprManagerLF getTransExprtManagerLF() {
		if (transExprManagerLF == null) {
			
			transExprManagerLF = new TransExprManagerLF();
			transExprManagerLF.addComponentListener(new ComponentAdapter() {
				@Override
				public void componentShown(ComponentEvent e) {
					onLFshown();
				}
			});
			GridBagLayout gridBagLayout = (GridBagLayout) transExprManagerLF.getLayout();
			gridBagLayout.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, 0.0, 0.0};
			gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 200, 0};
			// ҳ���� ��. ���� �� ��� ������ � ���������� ����� ���� ���������� ������
			transExprManagerLF.setParmSource(this);
		}
		return transExprManagerLF;
	}

	protected void onLFshown() {
		getChooseDataAccumTime().setText("0");
		getChooseDataDeviceNumber().setText("1");
		getChooseDataFinishTime().setText("0");
		getChooseDataNmodel().setText("0");

		
	}

	protected void onNDshown() {
		getChooseDataAccumTime().setText("5");
		getChooseDataDeviceNumber().setText("5");
		getChooseDataFinishTime().setText("250");
		getChooseDataNmodel().setText("500");
	}

	public double getModelingTime() {	
		return getChooseDataFinishTime().getDouble();
	}

	public int getnParallel() {
		return getChooseDataNmodel().getInt();
	}

	public int getnIntervals() {
		return (int)(getModelingTime()/getInterval());
	}

	public double getInterval() {
		return getChooseDataAccumTime().getDouble();
	}
	
	private TransExprManagerND getTransExprManagerND() {
		if (transExprManagerND == null) {
			transExprManagerND = new TransExprManagerND();
			transExprManagerND.addComponentListener(new ComponentAdapter() {
				@Override
				public void componentShown(ComponentEvent e) {
					onNDshown();
				}
			});
			// ҳ���� ��. ���� �� ��� ������ � ���������� ����� ���� 
			//���������� ������
			transExprManagerND.setParmSource(this);
		}
		return transExprManagerND;
	}

	public int getNdevice() {
		return getChooseDataDeviceNumber().getInt();		
	}
	
}  //  @jve:decl-index=0:visual-constraint="42,-8"
// @jve:decl-index=0:visual-constraint="10,8"
