package regresDpnd;

import finder.FinderByCdGr;

public class Regres3CdGr extends FinderByCdGr {


	public String toString() {
		return "a1*(x^a2)/(1-x)+a3";
	}

	@Override
	public double funcRegres(double x, double[] ar) {
		if(ar[2] < 0.5) return Float.MAX_VALUE;
		return ar[0]*Math.pow(x,ar[1])/(1-x)+ar[2];
	}	
	
	@Override
	protected double[] getCdGrStartArray() {
		return new double[] {5.0, 5.0, 5};
	}

	@Override
	protected double[] getCdStepArray() {
		return new double[] {0.01, 0.01, 0.01};
	}

	@Override
	protected double getGrStep() {
		return 0.01;
	}	


}
