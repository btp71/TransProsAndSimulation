package regresDpnd;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;

public class Regres1Tg extends FinderAsSumKfunc {

	@Override
	public List<Function<Double, Double>> functionList() {
		List<Function<Double, Double>> list = new LinkedList<>();
		list.add((x)-> x*x*Math.tan(x*Math.PI/2));
		
		return list;
	}

	public String toString() {
		return "a1*x*x*tg(x*pi/2)";
	}

}
