package regresDpnd;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;

/**
 * @author sanbok
 */

	public class Regres1_0Qavg extends FinderAsSumKfunc {
		@Override
		public List<Function<Double, Double>> functionList() {
			List<Function<Double, Double>> list = new LinkedList<>();
			list.add((x)-> x*x/(1-x));
			return list;
		}
	public String toString() {
		return "q=a1*x^2/(1-x)";
	}

		


}
