package regresDpnd;

import finder.FinderByCoord;

public class Regres3exppow extends FinderByCoord {

	public Regres3exppow() {
		super();
		// ����� ��������� � ������ ����� 
		parmArray = new  double[] {15.0,10.0, 0.7};
		stepArray = new  double[] {0.001, 0.001, 0.001};
	}

		@Override
	public double funcRegres(double x, double[] parmAr) {
		double a1 = parmAr[0];
		double a2 = parmAr[1];
		double a3 = parmAr[2];
		double y = a1*x*x/(1-x) - Math.exp(-a2*(x-a3)*(x-a3));
		return y;
	}

	
	public String toString() {
		return "a1*x*x/(1-x) - exp(-a2(x-a3)^2";
		
	}

}
