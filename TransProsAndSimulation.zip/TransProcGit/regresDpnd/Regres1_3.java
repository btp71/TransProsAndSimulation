package regresDpnd;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;

/**
 * @author sanbok
 */
public class Regres1_3 extends FinderAsSumKfunc {
	@Override
	public List<Function<Double, Double>> functionList() {
		List<Function<Double, Double>> list = new LinkedList<>();
		list.add((x)-> x!=1 ? x*x*x*x*x/(1-Math.sqrt(x)) : 100);
		return list;
	}
	public String toString() {
		return "a1*x^5/(1-sqrt(x))";
	}

}
