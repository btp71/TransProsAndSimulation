package regresDpnd;

import finder.FinderByCdGr;

public class Regres1CdGrPow7 extends FinderByCdGr {


	public String toString() {
		return "a1*(x^7)/(1-x)+2";
	}

	@Override
	public double funcRegres(double x, double[] ar) {
		
		return ar[0]*Math.pow(x,7)/(1-x)+2;
	}	
	
	@Override
	protected double[] getCdGrStartArray() {
		return new double[] {5.0};
	}

	@Override
	protected double[] getCdStepArray() {
		return new double[] {0.01};
	}

	@Override
	protected double getGrStep() {
		return 0.01;
	}	


}
