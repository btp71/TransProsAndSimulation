package regresDpnd;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;

/**
 * @author sanbok
 */
public class Regres1_2 extends FinderAsSumKfunc {
	@Override
	public List<Function<Double, Double>> functionList() {
		List<Function<Double, Double>> list = new LinkedList<>();
		list.add((x)->  x*x/(1-x));
		list.add((x)->  Math.exp(-(x-0.7)*(x-07)/0.05));
		return list;
	}
	public String toString() {
		return "a1*x*x/(1-x)-a2*exp(-20*(x-0.7)^2)";
	}

}
