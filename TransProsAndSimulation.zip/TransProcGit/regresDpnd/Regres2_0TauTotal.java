package regresDpnd;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;

/**
 * @author sanbok
 */

	public class Regres2_0TauTotal extends FinderAsSumKfunc {
		@Override
		public List<Function<Double, Double>> functionList() {
			List<Function<Double, Double>> list = new LinkedList<>();
			list.add((x)-> Math.pow(x,7.0)/(1-x));
			list.add((x)-> 1.0);
			return list;
		}
	public String toString() {
		return "q=a1*x^7/(1-x)+a2";
	}

		


}
