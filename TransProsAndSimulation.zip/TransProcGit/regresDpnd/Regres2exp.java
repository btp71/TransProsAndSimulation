package regresDpnd;

import finder.FinderByCoord;

public class Regres2exp extends FinderByCoord {

	public Regres2exp() {
		super();
		parmArray = new  double[]{6,0.5};
		stepArray = new double[]{0.01, 0.01};
	}


	@Override
	public double funcRegres(double x, double[] parmAr) {
		double a1 = parmAr[0];
		double a2 = parmAr[1];
		double y = a1*x*x*Math.exp(a2/(1-x*x));
		return y;
	}
	public String toString() {
		return "a1*x*x*exp(a2/(1-x*x))";
		
	}

}
