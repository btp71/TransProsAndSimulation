package regresDpnd;

import finder.FinderByCdGr;

public class Regres3CdGrPow extends FinderByCdGr {

	@Override
	public double funcRegres(double x, double[] prm) {
		return prm[0]*Math.pow(x,prm[1])/(1-x);
	}

	@Override
	protected double[] getCdGrStartArray() {
		return new double[] {1.0, 2.0};
	}

	@Override
	protected double[] getCdStepArray() {
		return new double[] {0.01, 0.01};
	}

	@Override
	protected double getGrStep() {
		return 0.01;
	}	

	public String toString() {
		return "a1*(x^a2)/(1-x)";
	}


}
