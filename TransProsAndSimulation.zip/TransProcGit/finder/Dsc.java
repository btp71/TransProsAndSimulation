package finder;

public class Dsc {
	int max;
	int state;
	Dsc next;

	public Dsc(int max) {
		super();
		this.max = max;
	}

	boolean move() {
		if(state < max) {
			state++;
			return true;
		}
		if(next != null){
			state = 0;
			return next.move();
		}
		return false;
	}
	public void setNext(Dsc pred) {
		this.next = pred;
	}
}
