package finder;

import java.util.List;
import java.util.function.Function;

import widgets.regres.LinearResolver;


/**
 * @author sanbok
 */
public abstract class FinderAsSumKfunc extends FinderRegresParm {


	public abstract	List<Function <Double, Double>>  functionList() ;
//	public int  getNkoef(){
//		return functionList().size();
//	}


	@Override
	public double[] findBestParm() {;

		int k = functionList().size();
		int p = factorArray.length;

		double[][] sumFF = new double[k][k];
		double[] sumFY = new double[k];

		for (int iRow = 0; iRow < k; iRow++) {
			for (int iCol = 0; iCol < k; iCol++) {
				sumFF[iRow][iCol] = 0;
				for (int i = 0; i < p; i++) {
					double x = factorArray[i];
					double f1 =functionList().get(iRow).apply(x);
					double f2 =functionList().get(iCol).apply(x);
					sumFF[iRow][iCol]+=f1*f2;
				}
			}
		}
		for (int iRow = 0; iRow < k; iRow++) {
			sumFY[iRow] = 0;
			for (int i = 0; i < p; i++) {

				Double x = (double)factorArray[i];
				double f = functionList().get(iRow).apply(x );
				sumFY[iRow]+=valueArray[i]*f;
			}
		}

		LinearResolver resolver = new LinearResolver(sumFF, sumFY);
		parmArray = resolver.resolve();
		return parmArray;
	}

	public double funcRegres(double x, double[] ar) {
		double res = 0;
		for (int i = 0; i < parmArray.length; i++) {
			res+=parmArray[i]*functionList().get(i).apply(x);		
		}
		return res;
	}

}
