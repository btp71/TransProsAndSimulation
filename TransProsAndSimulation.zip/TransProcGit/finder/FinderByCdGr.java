package finder;

import java.util.Arrays;

public abstract class FinderByCdGr extends FinderByStep {

	FinderByCoord cd = new FinderByCoord() {
		@Override
		public double funcRegres(double x, double[] prm) {
			return FinderByCdGr.this.funcRegres(x, prm);
		}	
	};

	FinderByGradient gr = new FinderByGradient() {
		@Override
		public double funcRegres(double arg, double[] parmAr) {
			return FinderByCdGr.this.funcRegres(arg, parmAr);
		}
	}; 

	double[] currntPoint = new double[getCdGrStartArray().length];
	double result;
	double[] basePoint = new double[getCdGrStartArray().length] ;

	private String search;

	@Override
	public double[] findBestParm() {
		System.arraycopy(getCdGrStartArray(), 0, 
				basePoint, 0, basePoint.length);
		setStartArray(getCdGrStartArray());

		cd.setFactorArray(getFactorArray());
		cd.setValueArray(getValueArray());
		cd.setStepArray(getCdStepArray());

		gr.setFactorArray(getFactorArray());
		gr.setValueArray(getValueArray());
		gr.setStep(getGrStep());

		best = Double.MAX_VALUE;	
		double bestOld = Float.MAX_VALUE;

		while(true) {
			//Start point creating generator
			GenerCoord gen = new GenerCoord(basePoint);
			while(true) {
				currntPoint  = gen.nextPoint();
				if(currntPoint == null) break;
				search = "Coordinates search";
				calcFor(cd);
				search = "Gradient search";
				calcFor(gr);
			}
			if(console != null) {
				console.print("Step finishrd whith result "
						+ String.valueOf(best)+"\n");

				console.print("Point "+	Arrays.toString(parmArray)+"\n");
			}
			if(best < bestOld) {
				bestOld = best;
				System.arraycopy(parmArray, 0, basePoint, 0, parmArray.length);
			}
			else break;
		}
		return parmArray;
	}


	void calcFor(FinderByStep fbs) {
		fbs.setStartArray(currntPoint);
		double[] ar = fbs.findBestParm();
		result = fbs.getBest();
		if(result < best) {
			best = result;

			if(console != null) {
				console.print(search +	
						" find "+	String.valueOf(best)+"\n");
			}

			System.arraycopy(ar, 0, parmArray, 0, ar.length);
		}
	}

	protected abstract double[] getCdGrStartArray();
	protected abstract double[] getCdStepArray();
	protected abstract double getGrStep();
	class GenerCoord{

		int n;
		Counter counter = new Counter();
		//����� �����
		double[] d;
		//����� ���� �������
		double[] left;

		GenerCoord(double[] base) {
			n = basePoint.length;
			d = new double[n];
			left = new double[n];
			for (int i = 0; i < n; i++) {
				d[i] = base[i]/3;
				if(d[i]< 0.01) d[i]=0.01;
			}
			for (int i = 0; i < n; i++) {
				left[i] = 0.2*base[i];
			}
			//��������� ��������� �������
			for (int i = 0; i < n; i++) {
				double right = 4*base[i];
				int max = (int) ((right - left[i])/d[i]+0.5);
				counter.addDscWithMax(max);
			}
		}

		double[] nextPoint() {
			int[] idx = counter.getStateAr();
			double[] point = new double[n];
			for (int i = 0; i < n; i++) {
				point[i] = left[i]+ idx[i]*d[i]; 		
			}	
			if(!counter.move())
				return null;
			return point;
		}

		public Counter getCounter() {
			return counter;
		}
	}

}



