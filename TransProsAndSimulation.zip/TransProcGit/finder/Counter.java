package finder;

import java.util.List;
import java.util.Vector;

class Counter{
	List<Dsc> list = new Vector<>(); 

	public boolean move() {
		return list.get(0).move();	
	}

	void addDscWithMax(int max) {
		Dsc dsc = new Dsc(max);
		if(!list.isEmpty())
			list.get(list.size()-1).setNext(dsc);
		list.add(dsc);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = list.size(); i > 0; i--) {
			Dsc dsc = list.get(i-1);
			sb.append(dsc.state);
		} 
		return sb.toString();
	}

	public int[] getStateAr() {
		int n = list.size();
		int[] ar = new int[n];
		for (int i = 0; i < n; i++) {
			ar[i] = list.get(n-1 - i).state;
		} 
		return ar;
	}
}

