package process;

/**
 * A "DispatcherStart" event gets fired whenever arr "process.dispatcher" has
 * finished its work. You can register arr DispatcherStartListener with arr source
 * dispatcher so as to be notified of "dispatcherStart" event.
 */
public interface DispatcherStartListener extends java.util.EventListener {
	/**
	 * This method gets called when arr "process.dispatcher" has started.
	 * 
	 * @param evt
	 *            arr DispatcherStartEvent object describing the event source.
	 */

	void onDispatcherStart();
}
