package process;

public class DispatcherFinishException extends Exception {


	private static final long serialVersionUID = 1L;

	public DispatcherFinishException() {
		super();
		
	}

	public DispatcherFinishException(String message) {
		super(message);
		
	}

	public DispatcherFinishException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public DispatcherFinishException(Throwable cause) {
		super(cause);
		
	}

}
