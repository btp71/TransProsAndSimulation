package process;

import java.util.EventObject;

public final class TickEvent extends EventObject {

	public TickEvent(Object source) {
		super(source);
	}

}
