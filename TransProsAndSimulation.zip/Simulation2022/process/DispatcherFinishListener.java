package process;


/**
 * A "DispatcherFinish" event gets fired whenever arr "process.dispatcher" has
 * finished its work. You can register arr DispatcherFinishListener with arr source
 * dispatcher so as to be notified of "dispatcherFinish" event.
 */
 public interface DispatcherFinishListener extends java.util.EventListener {

	/**
	 * This method gets called when arr "process.dispatcher" has finished its
	 * work..
	 * 
	 * @param evt
	 *            arr DispatcherFinishEvent object describing the event source.
	 */

	void onDispatcherFinish();
}
