package dynamic;

import java.util.function.BiFunction;

public abstract class DynamicActorRK4 extends DynamicActor {

	
	
	
	public DynamicActorRK4(double step, double value, double finishTime) {
		super(step, value, finishTime);
		
	}

	protected abstract BiFunction<Double, Double, Double> derivFunc();
	
	protected double calculateNewValue() {
		return rk4(derivFunc(), step, value);
	}


}
