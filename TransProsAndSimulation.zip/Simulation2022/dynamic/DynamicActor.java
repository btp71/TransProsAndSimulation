package dynamic;

import java.util.function.BiFunction;

import process.Actor;
import process.DispatcherFinishException;
import widgets.Painter;

public abstract class DynamicActor extends Actor {

	protected double step;
	protected double value;
	protected double newValue;
	protected double startTime;
	protected double finishTime;
	protected Painter painter;

	protected abstract double calculateNewValue();


	public DynamicActor(double step, double value, double finishTime) {
		super();
		this.step = step;
		this.value = value;
		this.finishTime = finishTime;
	}

	protected double rk4(BiFunction<Double, Double, Double>deriv, double step, double value) {
		double time = startTime - getDispatcher().getCurrentTime();
		double k1 = deriv.apply(time, value);
		double k2 = deriv.apply(time + step / 2, value + step * k1 / 2);
		double k3 = deriv.apply(time + step / 2, value + step * k2 / 2);
		double k4 = deriv.apply(time + step, value + step * k3);
		double newValue = value + step * (k1 + 2 * k2 + 2 * k3 + k4) / 6;
		return newValue;
	}


	@Override
	protected void rule() throws DispatcherFinishException {
		init();
		while (getDispatcher().getCurrentTime() <= finishTime) {
			value = calculateNewValue();
			holdForTime(step);
			if (painter != null && painter.getDiagram() != null) {
				painter.drawToXY((float) getDispatcher().getCurrentTime(), (float) value);
			}
		}

	}

	protected void init() {
	
		startTime = getDispatcher().getCurrentTime();
		if (painter != null && painter.getDiagram() != null) {
			painter.placeToXY((float) startTime, (float) value);
		}
	}

	public Painter getPainter() {
		return painter;
	}

	public void setPainter(Painter painter) {
		this.painter = painter;
	}

	public double getValue() {
		return value;
	}
}
