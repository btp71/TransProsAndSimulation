package widgets.trans;

public interface ITransMonitoring {
	void resetAccum();
	double getAccumAverage();
}