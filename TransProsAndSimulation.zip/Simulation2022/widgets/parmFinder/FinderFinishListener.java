package widgets.parmFinder;

/**
 * Insert the type's description here. Creation date: (25.03.2006 21:03:08)
 * 
 * @author: Administrator
 */
public interface FinderFinishListener extends java.util.EventListener {
	/**
	 * Insert the method's description here. Creation date: (25.03.2006
	 * 21:04:19)
	 */
	void onFinderFinish(java.util.EventObject evt);
}
