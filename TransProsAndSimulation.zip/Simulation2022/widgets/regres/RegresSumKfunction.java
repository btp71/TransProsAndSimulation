package widgets.regres;

import java.util.List;
import java.util.function.Function;


/**
 * @author sanbok
 */
public abstract class RegresSumKfunction extends RegresTester {


	double[] arr;

	public abstract	List<Function<Double, Double>>  functionList() ;
	/*
	 * (non-Javadoc)
	 * 
	 * @see simulationRegress.RegresTesters#k()
	 */
	public int k() {
		return functionList().size();
	}

	public void calculateParameters() {
		int k = functionList().size();
		int p = factorArray.length;
		
		double[][] sumFF = new double[k][k];
		double[] sumFY = new double[k];

		for (int iRow = 0; iRow < k; iRow++) {
			for (int iCol = 0; iCol < k(); iCol++) {
				sumFF[iRow][iCol] = 0;
				for (int i = 0; i < p; i++) {
					double x = factorArray[i];
					double f1 =functionList().get(iRow).apply(x);
					double f2 =functionList().get(iCol).apply(x);
					sumFF[iRow][iCol]+=f1*f2;
				}
			}
		}
		for (int iRow = 0; iRow < k(); iRow++) {
			sumFY[iRow] = 0;
			for (int i = 0; i < p; i++) {
				
				Double x = (double)factorArray[i];
				double f = functionList().get(iRow).apply(x );
				sumFY[iRow]+=avrgArray[i]*f;
			}
		}

		  LinearResolver resolver = new LinearResolver(sumFF, sumFY);
	      arr = resolver.resolve();
	      
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see simulationRegress.RegresTesters#f(java.lang.Float)
	 */
	public double f(double x) {
		double res = 0;
		for (int i = 0; i < arr.length; i++) {
			res+=arr[i]*functionList().get(i).apply(x);		
		}
		return res;
	}


	public String parametersAsString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < arr.length; i++) {
			sb.append("a").append(i+1).append(" = ")
			.append(String.format("%1.4f",arr[i])).append("\n");
		}
		return sb.toString();
	}

	
	public double[] getArr(){
		return arr;
	}
	
}
