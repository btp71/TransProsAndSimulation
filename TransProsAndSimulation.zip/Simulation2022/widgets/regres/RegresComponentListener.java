package widgets.regres;

public interface RegresComponentListener extends java.util.EventListener {
	/**
	 * 
	 * @param newEvent
	 *            java.util.EventObject
	 */
	void JButtonStartAction_actionPerformed(java.util.EventObject newEvent);
}
