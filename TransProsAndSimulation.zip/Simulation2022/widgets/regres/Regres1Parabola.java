package widgets.regres;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

/**
 * @author sanbok
 */

	public class Regres1Parabola extends RegresSumKfunction {
		@Override
		public List<Function<Double, Double>> functionList() {
			List<Function<Double, Double>> list = new LinkedList<>();
			list.add((x)-> x*x);
			return list;
		}
	public String getLabel() {
		return "q=a1*x*x";
	}
}
