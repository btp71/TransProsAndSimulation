package widgets.regres;

import java.util.List;
import java.util.Map;


public interface IRegresable {
	 Map<Double, List<Double>> getResultMap();
	
}